# -----------------------------------------------------------------------------
# Import Modules
# -----------------------------------------------------------------------------

# maya
import maya.cmds as cmds
import maya.mel as mel

import re

# itertools
from itertools          import tee
from itertools          import islice
from itertools          import chain
from itertools          import izip

from ncTools.tools.ncToolboxGlobals   import ncToolboxGlobals as G

# -----------------------------------------------------------------------------
# Functions
# -----------------------------------------------------------------------------
def delete_duplicates(array):
    return list(set(array))

def get_prev_current_next(iterable):
    previous, current, next = tee(iterable, 3)
    previous = chain([None], previous)
    next = chain(islice(next, 1, None), [None])
    return izip(previous, current, next)

def get_target(target, attribute=None, anim_curve=None, anim_layer=None, attribute_options=None, node=None, selected = False, get_from = None, control_name=None):

    if target == "anim_curve":

        node_attribute = "{0}.{1}".format(node, attribute)
        print node
        if not is_control_in_anim_layer(node, anim_layer):
            print node_attribute, "not in layer"
            return None

        anim_curve = None
        if anim_layer == cmds.animLayer(query=True, root=True):
            print "base"
            connections = cmds.listConnections(node_attribute, type="animBlendNodeBase", s=True, d=False)
            print connections
            blendNode = None
            while connections:
                print connections
                blendNode = connections[0]
                connections = cmds.listConnections(blendNode, type="animCurve", s=True, d=False)
            plug = "{0}.inputA".format(blendNode)
        else:
            cmd = 'animLayer -q -layeredPlug "{0}" "{1}"'.format(node_attribute, anim_layer)
            anim_curve = mel.eval(cmd)
        return anim_curve


    if target == "anim_layers":
        all_anim_layers = cmds.ls(type = "animLayer")

        if selected == False:
            anim_layers = all_anim_layers

        elif selected == True:
            anim_layers = []
            for anim_layer in all_anim_layers:
                if cmds.animLayer(anim_layer, query = True, sel=True):
                    anim_layers.append(anim_layer)

        return anim_layers

    if target == "attributes":
        options_true = []
        for option in attribute_options:
            option_true = "{0} = True".format(option)
            options_true.append(option_true)
        options_string = ", ".join(options_true)

        attributes = eval("cmds.listAttr('{0}', {1})".format(node, options_string))
        return attributes



    if target == "rigs":
        if selected is False:
            rigs = []
            transform_nodes = cmds.ls(type = "transform")
            for node in transform_nodes:
                if "RigPuppet" in node:
                    if node.endswith("GRP"):
                        rigs.append(node)

        if selected is True:
            rigs = []
            all_rigs = get_target(target = "rigs", selected = False)
            selected_nodes = cmds.ls(sl=True, type = "transform")
            namespaces = []
            for node in selected_nodes:
                namespace = get_target(node = node, target = "namespace")
                namespaces.append(namespace)
            namespaces = delete_duplicates(namespaces)

            for namespace in namespaces:
                for rig in all_rigs:
                    if namespace in rig:
                        rigs.append(rig)

        return rigs


    if target == "namespace":
        namespace = node.rpartition(":")[0]
        return namespace


    if target == "control_name":
        namespace = get_target(target="namespace", selected=True, node=node)
        control = namespace + ":" + control_name + "_CTRL"

        return control

    if target == "controls":
        if selected == True:
            selection = cmds.ls(sl=1)
            controls = []
            for object in selection:
                if object.endswith("_CTRL"):
                    controls.append(object)

        if selected == False:
            global_control = get_target(target="control_name", control_name="global", node=node)
            global_control_relatives = cmds.listRelatives(global_control, ad=True)

            relatives = []
            for control in global_control_relatives:
                if control.endswith("_CTRL"):
                    relatives.append(control)
            relatives.reverse()
            controls = [global_control] + relatives

        return controls



    if target == "frames":
        if selected is True:
            G.playback_slider = G.playback_slider or mel.eval("$tmpVar = $gPlayBackSlider")
            timeline_frames = []
            timeline_frame_range = cmds.timeControl(G.playback_slider, query = True, rangeArray = True)
            timeline_frames = range(int(timeline_frame_range[0]), int(timeline_frame_range[1]))
            graphEditor_frames = cmds.keyframe(query=True, selected=True, timeChange=True)

            if len(timeline_frames) > 1:
                frames = timeline_frames
            elif graphEditor_frames is None:
                frames = timeline_frames
            elif len(timeline_frames) == 1 and len(graphEditor_frames) > 0:
                frames = graphEditor_frames

        return frames


    if target == "anim_curves":
        if selected is True:
            anim_curves = cmds.ls(sl=True, type="animCurve")

        elif selected is False:
            anim_curves = cmds.ls(type="animCurve")
        return anim_curves

    if target == "key_times":
        if selected is True:

            if get_from == "graphEditor":
                key_times = cmds.keyframe(anim_curve, query = True, selected = True, timeChange = True)

            elif get_from == "timeline":
                timeline_range = get_timeline_range()

                all_keys = cmds.keyframe(anim_curve, query = True, timeChange = True)
                key_times = []
                for frame in xrange(int(timeline_range[0]), int(timeline_range[1])):
                    if frame in all_keys:
                        key_times.append(frame)

        elif selected is False:
            key_times = cmds.keyframe(anim_curve, query = True, timeChange = True)

        return key_times

    if target == "key_values":
        if selected is True:
            if get_from == "graphEditor":
                key_values = cmds.keyframe(anim_curve, query = True, valueChange = True)

            elif get_from == "timeline":
                timeline_range = get_timeline_range()

                key_times = get_target("key_times",  anim_curve = anim_curve, selected = True, get_from = "timeline")

                key_values = []
                for frame in key_times:
                    key_value = cmds.keyframe(anim_curve, query = True, time = (frame, frame), valueChange = True)[0]
                    key_values.append(key_value)

        elif selected is False:
            key_values = cmds.keyframe(anim_curve, query = True, valueChange = True)

        return key_values

    if target == "opposite_control":

        if ":l_" in node:
            target = node.replace(":l", ":r")
        elif ":r_" in node:
            target = node.replace(":r_", ":l_")
        else:
            target = node
        return target

def get_timeline_frame():
    timeline_frame = cmds.currentTime(query = True)
    return timeline_frame

def get_timeline_range():
    G.playback_slider = G.playback_slider or mel.eval("$tmpVar = $gPlayBackSlider")
    timeline_range = cmds.timeControl(G.playback_slider, query = True, rangeArray = True)
    return timeline_range

def get_selected():
    return cmds.ls(sl=True)

def store_animation_data(time_range=(None,None), rig=None):
    #Stores the attribute values in dictionary
    rig_namespace = get_target("namespace", node=rig)
    anim_data = {}
    for time in range(int(time_range[0]), int(time_range[1]+1)):
        attribute_dict = {}
        control_attributes = get_control_attributes(node=rig)
        for control_attribute in control_attributes:
            value = cmds.getAttr(rig_namespace + ":" + control_attribute, time=time)
            attribute_dict[control_attribute] = value
        anim_data[time] = attribute_dict
    return anim_data


def get_control_attributes(node=None):
    control_attributes = []
    for control in get_target("controls", selected = False, node=node):
        control_name = control.rpartition(":")[2]
        unlocked_attributes = cmds.listAttr(control, w=True, unlocked=True, keyable=True) or []
        channelbox_attributes =  cmds.listAttr(control, w=True, unlocked=True, cb=True) or []
        attributes = unlocked_attributes + channelbox_attributes

        for attribute in attributes:
            control_attribute = control_name + "." + attribute
            control_attributes.append(control_attribute)
    return control_attributes

def is_control_in_anim_layer(control, anim_layer):
    affected_layers = cmds.animLayer([control], query=True, affectedLayers=True) or ["BaseAnimation"]
    if anim_layer in affected_layers:
        return True
    else:
        return False
